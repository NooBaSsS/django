from django.urls import path
from . import views


urlpatterns = [
    path('index/', views.index),
    path('main/', views.main),
    path('test/<int:rub>', views.test),
]
