from django.shortcuts import render, redirect
from django.http import HttpResponseNotAllowed
from django.conf import settings
from .forms import UserForm
from django.core.files.storage import FileSystemStorage

users = ['a', 'b']

base_dir = settings.BASE_DIR


def index(request):
    context = {
        'users': users
    }
    return render(request, 'my_app/index.html', context)


def add(request):
    if request.method == 'GET':
        form_fields = UserForm()
        context = {
            'form_fields': form_fields,
        }
        return render(request, 'my_app/add.html', context)
    elif request.method == 'POST':
        form_fields = UserForm(request.POST, request.FILES)
        if form_fields.is_valid():
            file = request.FILES['file']
            file_system = FileSystemStorage()
            file_name = file_system.save(file.name, file)
            file_url = file_system.url(file_name)
            context = {
                'url': file_url
            }
            return render(request, 'my_app/download.html', context)
        else:
            context = {
                        'form_fields': form_fields,
            }
            return render(request, 'my_app/add.html', context)
    else:
        return HttpResponseNotAllowed(['POST', 'GET'],
                                      content='этот метод не разрешен'
                                      )
