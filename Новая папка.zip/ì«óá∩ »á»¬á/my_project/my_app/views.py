from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime


def index(request):
    return HttpResponse('test')


def main(request):
    today_day = datetime.now().day
    today_month = datetime.now().month
    context = {'is_new_year': today_day == 1 and today_month == 1}
    return render(request, 'my_app/index.html', context)
