from django.shortcuts import render, redirect
from django.http import HttpResponseNotAllowed
from django import forms

users = ['a', 'b']


class UserForm(forms.Form):
    first_name = forms.CharField(max_length=100, min_length=1, label='имя:')
    last_name = forms.CharField(max_length=100, min_length=1, label='фамилия:')


def index(request):
    context = {
        'users': users
    }
    return render(request, 'my_app/index.html', context)


def add(request):
    if request.method == 'GET':
        form_fields = UserForm()
        context = {
            'form_fields': form_fields,
        }
        return render(request, 'my_app/add.html', context)
    elif request.method == 'POST':
        form_fields = UserForm(request.POST)
        if form_fields.is_valid():
            first_name = form_fields.cleaned_data['first_name']
            last_name = form_fields.cleaned_data['last_name']
            user = first_name + ' ' + last_name
            users.append(user)
            return redirect('my_app:index')
        else:
            context = {
                        'form_fields': form_fields,
            }
            return render(request, 'my_app/add.html', context)
    else:
        return HttpResponseNotAllowed(['POST', 'GET'],
                                      content='этот метод не разрешен'
                                      )
