from django.shortcuts import render, redirect

users = ['a', 'b']


def index(request):
    context = {
        'users': users
    }
    return render(request, 'my_app/index.html', context)


def add(request):
    if request.method == 'GET':
        return render(request, 'my_app/add.html')
    elif request.method == 'POST':
        user = request.POST.get('username', False)
        users.append(user)
        return redirect('index')
