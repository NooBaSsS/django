from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime


def index(request):
    return HttpResponse('test')


def main(request):
    today_day = datetime.now().day
    today_month = datetime.now().month
    context = {'is_new_year': today_day == 1 and today_month == 1}
    return render(request, 'my_app/index.html', context)


def test(request, rub):
    usd = round(rub / 97.7, 2)
    kzt = round(rub / 0.2, 2)
    context = {'rub': rub, 'usd': usd, 'kzt': kzt}

    return render(request, 'my_app/test1.html', context)
